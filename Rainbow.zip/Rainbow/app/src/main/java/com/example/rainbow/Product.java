package com.example.rainbow;

public class Product {
    
}
